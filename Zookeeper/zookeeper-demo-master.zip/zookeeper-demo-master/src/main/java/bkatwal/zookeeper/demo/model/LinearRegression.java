package bkatwal.zookeeper.demo.model;

import java.util.ArrayList;
import java.util.List;
import java.util.function.DoubleBinaryOperator;

public class LinearRegression {

    private List<Double> xValues = new ArrayList<>();
    private List<Double> yValues = new ArrayList<>();
    private double slope;
    private double intercept;

    public void setData(List<Double> xValues,List<Double> yValues) {
        this.xValues = xValues;
        this.yValues = yValues;
    }

    public void train() {
        int n = xValues.size();
        double sumX = 0.0, sumY = 0.0, sumXY = 0.0, sumX2 = 0.0;

        for (int i = 0; i < n; i++) {
            double x = xValues.get(i);
            double y = yValues.get(i);

            sumX += x;
            sumY += y;
            sumXY += x * y;
            sumX2 += x * x;
        }

        // Calculate slope (m) and intercept (b)
        slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
        intercept = (sumY - slope * sumX) / n;
        System.out.println(slope);
        System.out.println(intercept);
    }

    public double predict(double x) {
        return slope * x + intercept;
    }

    public Double getSlope(){
        return this.slope;
    }

    public Double getIntersect(){
        return this.intercept;
    }

    public void setSlope(double slope){
        this.slope = slope;
    }

    public void setIntersect(double intersect){
        this.intercept = intersect;
    }

    public void printModel() {
        System.out.println("Linear Regression Model: y = " + slope + " * x + " + intercept);
    }
}
