package bkatwal.zookeeper.demo.util;

import java.util.ArrayList;
import java.util.List;

/** @author "Bikas Katwal" 26/03/19 */
public final class DataStorage {

  private static  Double slope;
  private static Double intersect;

  public static Double getSlope(){
    return slope;
  }

  public static Double getIntersect(){
    return intersect;
  }

  public static void setSlope(double slope_){
    slope = slope_;
  }

  public static void setIntersect(double intersect_){
    intersect = intersect_;
  }

  public static List<Double> getData(){
    List<Double> x = new ArrayList<>();
    x.add(slope);
    x.add(intersect);

    return x;
  }

  public static void setData(List<Double> data){
    slope = data.get(0);
    intersect = data.get(1);
  }

  private DataStorage() {}
}
