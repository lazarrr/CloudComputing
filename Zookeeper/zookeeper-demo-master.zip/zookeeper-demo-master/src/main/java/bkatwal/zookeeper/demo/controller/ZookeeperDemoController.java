package bkatwal.zookeeper.demo.controller;

import static bkatwal.zookeeper.demo.util.ZkDemoUtil.getHostPostOfServer;
import static bkatwal.zookeeper.demo.util.ZkDemoUtil.isEmpty;

import bkatwal.zookeeper.demo.model.LinearRegression;
import bkatwal.zookeeper.demo.util.ClusterInfo;
import bkatwal.zookeeper.demo.util.DataStorage;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

/** @author "Bikas Katwal" 26/03/19 */
@RestController
public class ZookeeperDemoController {

  private RestTemplate restTemplate = new RestTemplate();

  @PutMapping("/updateModel")
  public ResponseEntity<String> uploadCsvFile(HttpServletRequest request, @RequestParam("file") MultipartFile file) {

    String requestFrom = request.getHeader("request_from");
    String slope = request.getHeader("slope");
    String intersect = request.getHeader("intersect");
    String leader = ClusterInfo.getClusterInfo().getMaster();

    // request from leader to followers
    if (!isEmpty(requestFrom) && requestFrom.equalsIgnoreCase(leader)) {
      System.out.println("successfully updated model");

      DataStorage.setSlope(Double.parseDouble(slope));
      DataStorage.setIntersect(Double.parseDouble(intersect));
      return ResponseEntity.ok("SUCCESS");
    }

    if (file.isEmpty()) {
      return new ResponseEntity<>("File is empty", HttpStatus.BAD_REQUEST);
    }

    if (amILeader()) {

      List<Double> x = new ArrayList<>();
      List<Double> y = new ArrayList<>();

      try {
        // Read the CSV file content
        BufferedReader reader = new BufferedReader(new InputStreamReader(file.getInputStream()));
        String line;
        while ((line = reader.readLine()) != null) {
          String[] values = line.split(",");
          x.add(Double.parseDouble(values[0].trim()));
          y.add(Double.parseDouble(values[1].trim()));
        }
        reader.close();

        // train a model
        LinearRegression model = new LinearRegression();
        model.setData(x, y);
        model.train();

        // sinc model with other nodes
        List<String> liveNodes = ClusterInfo.getClusterInfo().getLiveNodes();

        for (String node : liveNodes) {

          if (getHostPostOfServer().equals(node)) {
            continue;
          } else {
            System.out.println("Sync data with " + node);
            String requestUrl = "http://"
                .concat(node)
                .concat("updateModel");

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.MULTIPART_FORM_DATA);
            headers.add("request_from", leader);
            headers.add("slope", model.getSlope().toString());
            headers.add("intersect", model.getIntersect().toString());

            headers.setContentType(MediaType.MULTIPART_FORM_DATA);

            
            MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
            body.add("file", file.getResource());
            HttpEntity<MultiValueMap<String, Object>> entity = new HttpEntity<>(body, headers);
            restTemplate.exchange(requestUrl, HttpMethod.PUT, entity, String.class);
          }
        }
        return new ResponseEntity<>("File uploaded successfully", HttpStatus.OK);
      } catch (Exception e) {
        System.out.println(e);
        return new ResponseEntity<>("Failed to upload file", HttpStatus.INTERNAL_SERVER_ERROR);
      }
    } else {
      // send data to leader
      System.out.println("Send data to leader ");
      String requestUrl = "http://"
          .concat(leader)
          .concat("updateModel");

      HttpHeaders headers = new HttpHeaders();
      headers.setConnection(MediaType.MULTIPART_FORM_DATA_VALUE);

      MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
      body.add("file", file.getResource());
      HttpEntity<MultiValueMap<String, Object>> entity = new HttpEntity<>(body, headers);
      restTemplate.exchange(requestUrl, HttpMethod.PUT, entity, String.class);

      return ResponseEntity.ok("Request has been forwarded to the leader.");
    }
  }

  private boolean amILeader() {
    String leader = ClusterInfo.getClusterInfo().getMaster();
    return getHostPostOfServer().equals(leader);
  }

  @PostMapping("/predict")
    public ResponseEntity<List<Double>> predict(@RequestBody List<Double> features) {
        try {
            List<Double> data = this.getData();
            List<Double> response = new ArrayList<>();
            LinearRegression model = new LinearRegression();
            model.setSlope(data.get(0));
            model.setIntersect(data.get(1));
            for (Double feature : features) {
              response.add(model.predict(feature));
            }
            return ResponseEntity.ok().body(response);
        } catch (Exception e) {
            return null;
        }
    }

  @GetMapping("/getData")
  public List<Double> getData() {

    return DataStorage.getData();
  }

  @GetMapping("/clusterInfo")
  public ResponseEntity<ClusterInfo> getClusterinfo() {

    return ResponseEntity.ok(ClusterInfo.getClusterInfo());
  }
}
